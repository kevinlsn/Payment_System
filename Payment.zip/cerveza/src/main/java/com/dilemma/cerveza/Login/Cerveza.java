/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.dilemma.cerveza.Login;

import com.dilemma.cerveza.Login.Login;

/**
 *
 * @author kevinlsn
 */
public class Cerveza {

    public static void main(String[] args) {
        
        //Cambio de página
        Login LoginFrame = new Login();
        LoginFrame.setVisible(true);
        LoginFrame.pack();
        LoginFrame.setLocationRelativeTo(null);
        
    }
}
